from django import forms

class NameForm(forms.Form):
    queri = forms.CharField(label='Query', max_length=100)
    numoftweets=forms.IntegerField(label='Number of Tweets')
    numofdays=forms.IntegerField(label='Number of Days')