from django.http import HttpResponse
from .sa import tsa

HTMLSTRING="""
<h1>Hello WORLD</h1>
"""

def home_view(request):
    return HttpResponse(HTMLSTRING)




############################

from django.http import HttpResponseRedirect
from django.shortcuts import render

from .forms import NameForm

def get_name(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = NameForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            #print(form.get_context())
            #print(form.data["queri"])
            #print(form.data["numoftweets"])
            #print(form.data["numofdays"])
            q=form.data["queri"]
            t=form.data["numoftweets"]
            d=form.data["numofdays"]
            dict={'q': q,'t': t,'d': d }
            #return HttpResponseRedirect('/')
            output=tsa(q,t,d)
            return render(request, 'index.html',
                  {'graph': output[0], 'csvhtml': output[1], 'bar': output[2], 'q': q, 't': t, 'd': d})
    # if a GET (or any other method) we'll create a blank form
    else:
        form = NameForm()
        return render(request, 'index.html',{'form':form})