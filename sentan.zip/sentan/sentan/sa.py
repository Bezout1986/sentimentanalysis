import string

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import datetime as dt
import re
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import snscrape.modules.twitter as sntwitter
import nltk
from io import StringIO, BytesIO
import base64
import mimetypes

def tsa(query,tw,day):
        #Get user input
        #query = input("Query: ")

        #As long as the query is valid (not empty or equal to '#')...
        if query != '':
            #noOfTweet = input("Enter the number of tweets you want to Analyze: ")
            noOfTweet=tw
            if noOfTweet != '' :
                #noOfDays = input("Enter the number of days you want to Scrape Twitter for: ")
                noOfDays=day
                if noOfDays != '':
                        #Creating list to append tweet data
                        tweets_list = []
                        now = dt.date.today()
                        now = now.strftime('%Y-%m-%d')
                        yesterday = dt.date.today() - dt.timedelta(days = int(noOfDays))
                        yesterday = yesterday.strftime('%Y-%m-%d')
                        for i,tweet in enumerate(sntwitter.TwitterSearchScraper(query + ' lang:en since:' +  yesterday + ' until:' + now + ' -filter:links -filter:replies').get_items()):
                            if i > int(noOfTweet):
                                break
                            tweets_list.append([tweet.date, tweet.id, tweet.content, tweet.user.username])

                        #Creating a dataframe from the tweets list above
                        df = pd.DataFrame(tweets_list, columns=['Datetime', 'Tweet Id', 'Text', 'Username'])

                        #print(df)
        df.to_csv('sa1.csv')

        # Create a function to clean the tweets
        from nltk.corpus import stopwords
        from nltk import word_tokenize
        stopwords = set(stopwords.words('english'))
        def cleanTxt(text):
            text = re.sub('@[A-Za-z0–9]+', '', text)  # Removing @mentions
            text = re.sub('#', '', text)  # Removing '#' hash tag
            text = re.sub('RT[\s]+', '', text)  # Removing RT
            text = re.sub('https?:\/\/\S+', '', text)  # Removing hyperlink
            text = word_tokenize(text)
            text = [word.lower() for word in text if word.isalpha()]
            punct = str.maketrans('', '', string.punctuation)
            text = [word.translate(punct) for word in text]
            text = [word for word in text if not word in stopwords]
            return text

        #applying this function to Text column of our dataframe
        df["Text"] = df["Text"].apply(cleanTxt)




        from collections import Counter

        def counter(text):
            cnt=Counter()
            for msgs in text:
                for msg in msgs:
                    cnt[msg] +=1
            return cnt
        text_cnt =counter(df["Text"])
        #print(text_cnt.most_common(10))

        import seaborn as sns

        common_words=text_cnt.most_common(40)
        common_words = pd.DataFrame(common_words,columns=['Words','Counts'])
        #print(common_words)
        plt.figure(figsize=(16,20))
        sns.barplot(y='Words', x='Counts',data=common_words)
        plt.xlabel("Occurrences")
        plt.ylabel("Words")
        plt.title("Frequency of Most common words")
        plt.savefig('foo.png')
        with open("foo.png","rb") as img:
            data=str(base64.b64encode(img.read()))
            data=data[1:]
            data=data[1:]
            data=data[:-1]

        df1 = pd.read_csv('sa1.csv')
        keep_col = ['Datetime', 'Text', 'Username']
        df1 = df1[keep_col]
        df1.to_csv("sa2.csv", index=False)
        html_string = df1.to_html()

        #Sentiment Analysis
        # Assigning Initial Values
        positive = 0
        negative = 0
        neutral = 0
        # Creating empty lists
        tweet_list1 = []
        neutral_list = []
        negative_list = []
        positive_list = []
        for tweet in text_cnt:
            tweet_list1.append(tweet)
            analyzer = SentimentIntensityAnalyzer().polarity_scores(tweet)
            neg = analyzer['neg']
            neu = analyzer['neu']
            pos = analyzer['pos']
            comp = analyzer['compound']

            if neg > pos:
                negative_list.append(tweet)  # appending the tweet that satisfies this condition
                negative += 1  # increasing the count by 1
            elif pos > neg:
                positive_list.append(tweet)  # appending the tweet that satisfies this condition
                positive += 1  # increasing the count by 1
            elif pos == neg:
                neutral_list.append(tweet)  # appending the tweet that satisfies this condition
                neutral += 1  # increasing the count by 1


        # Converting lists to pandas dataframe
        tweet_list1 = pd.DataFrame(tweet_list1)
        neutral_list = pd.DataFrame(neutral_list)
        negative_list = pd.DataFrame(negative_list)
        positive_list = pd.DataFrame(positive_list)
        # using len(length) function for counting
        #print("Since " + noOfDays + " days, there have been", len(tweet_list1), "tweets on " + query, end='\n*')
        #print("Positive Sentiment:", '%.2f' % len(positive_list), end='\n*')
        #print("Neutral Sentiment:", '%.2f' % len(neutral_list), end='\n*')
        #print("Negative Sentiment:", '%.2f' % len(negative_list), end='\n*')
        #####
        sentdata = {'Positive': len(positive_list), 'Negative': len(negative_list)}
        sentiment = list(sentdata.keys())
        numtweets = list(sentdata.values())

        fig = plt.figure(figsize=(10, 5))

        # creating the bar plot
        plt.bar(sentiment, numtweets, color='blue', width=0.3)

        plt.xlabel("Sentiment")
        plt.ylabel("Number of Tweets")
        plt.title("Sentiment Analysis of scrapped tweets")
        plt.savefig('bar.png')

        with open("bar.png", "rb") as img2:
            sdata = str(base64.b64encode(img2.read()))
            sdata = sdata[1:]
            sdata = sdata[1:]
            sdata = sdata[:-1]


        #####

        output = ['','','']
        output[0]=data
        output[1]=html_string
        output[2]=sdata
##
        return output
##

